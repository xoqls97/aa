package day01;

public class HelloWorld {

	public static void main(String[] args) {
		// 한 줄 주석=> ctrl + /
		/* 여러줄 주석
		 * println() : 줄바꿈이 있는 출력
		 * print() : 줄바꿈이 없는 출력
		 * printf() : 형식이 있는 출력(c에서 주로 사용)
		 *  */
		System.out.println("Hello world~~!!!");
		System.out.println(1234);
		int num1 ;
		int num2, num3, num4;
		num1 = 123;
       
		System.out.println(num1);
        
	}

}
