package day06;

import java.util.Scanner;

public class 과제 {

	public static void main(String[] args) {
		/* 가위바위보게임 만들기
		 *  컴퓨터가 가위, 바위, 보 중 랜덤으로 선택
		 *  (0=가위, 1=바위, 2=보)
		 *  나도 가위, 바위, 보 중 선택해서 입력(숫자, 문자상관없음.)
		 *  결과 =>
		 *  컴퓨터 가위, 나>가위=>결과 무승부입니다.
		 * */
		Scanner scan = new Scanner(System.in);

		System.out.println("가위바위보 시작!");
		
			int a = scan.nextInt();
                
		
			
			if(a == 0) {
				System.out.println("나는 가위를 냈습니다.");
				int cpu = (int)(Math.random()*3);
				switch(cpu) {
				case 0:
					System.out.println("컴퓨터가 가위를 냈습니다.");
					System.out.println("비겼네용");
					break;
				case 1:
					System.out.println("컴퓨터가 바위를 냈습니다.");
					System.out.println("졌네용");
					break;
				
				case 2:
					System.out.println("컴퓨터가 보를 냈습니다.");
					System.out.println("이겼네용");
					break;
					
				}	
			}
			if(a ==1) {
				System.out.println("나는 바위를 냈습니다.");
				int cpu = (int)(Math.random()*3);
				switch(cpu) {
				case 0:
					System.out.println("컴퓨터가 가위를 냈습니다.");
					System.out.println("이겼네용");
					break;
				case 1:
					System.out.println("컴퓨터가 바위를 냈습니다.");
					System.out.println("비겼네용");
					break;
				case 2:
					System.out.println("컴퓨터가 보를 냈습니다.");
					System.out.println("졌네용");
					break;
					
				}
			}
			if(a==2) {
				System.out.println("나는 보를 냈습니다.");
				int cpu = (int)(Math.random()*3);
			
				switch(cpu) {
				case 0:
					System.out.println("컴퓨터가 가위를 냈습니다.");
					System.out.println("졌네용");
					break;
				case 1:
					System.out.println("컴퓨터가 바위를 냈습니다.");
					System.out.println("이겼네용");
					break;
				case 2:
					System.out.println("컴퓨터가 보를 냈습니다.");
					System.out.println("비겼네용");
					break;
					
				}
			
			
		}
			

		scan.close();

	}

}
